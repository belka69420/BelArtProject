﻿namespace Model
{
    public class Class1
    {

    }
}
